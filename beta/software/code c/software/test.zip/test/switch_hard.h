#ifndef switch_hard_h
#define switch_hard_h

int switch_hard();

#endif
